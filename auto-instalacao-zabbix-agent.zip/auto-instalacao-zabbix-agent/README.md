# Auto Instalação do Zabbix Agent 
Está role cria um processo de auto instalação do zabbix agent, utilizando script em python, ferramentas ansible e zabbix  

## Dependencias

- Ansible
- Policy aws ec2 attach ao zabbix-server segue exemplo:
```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": "ec2:ModifyInstanceAttribute",
            "Resource": [
                "arn:aws:ec2:*:CONTA_AWS:instance/*",
                "arn:aws:ec2:*:CONTA_AWS:security-group/*"
            ]
        }
    ]
}
```
### Em "CONTA_AWS" insira a conta do cliente

## Playbook exemplo

### Necessário preencher todas as variaveis  

```
---
- hosts: all
  vars:
  # Deixar localhost, colocar /zabbix caso necessite
    ZABBIX_URL: "http://localhost/"
  # Deixar localhost, colocar /zabbix caso necessite
    url_zabbix_api: "http://localhost/api_jsonrpc.php"
  # Usuario do Zabbix
    user_zabbix: "Admin"
  # Senha do Zabbix
    pass_zabbix: ""
  # IP privado do Zabbix
    ZABBIX_PRIVATE_IP: ""
  # IP ou DNS que vai ficar na conf do zabbix agent 
    zabbix_server_ip_or_dns: ""
  # Região onde estão as instancias
    regiao: "us-east-1"
  # Security Group do Zabbix Agent
    sg_id: ""
  become: yes

  roles:
    - auto-instalacao-zabbix-agent
```
## Executar ansible na maquina do Zabbix Server

## Após a execução do ansible

### Verificar se estrutura de arquivos e diretórios esta correta

 <img src="http://i.imgur.com/fx9J8XJ.png"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" />
     
### Colocar as pems das maquinas que serão monitoradas no diretório "/home/centos/zabbix-agent/pems"

### Após colocar as pems, habilitar o item "Instancias não monitoradas" que esta no host Zabbix Server

## Fluxo de trabalho

Supondo que uma instancia com ip: **172.1.0.3** seja provisionada na AWS e sua pem esteja no diretorio **pems**. Sera realizado o fluxo de instalação do agent nessa instancia

Fluxo  de instalação do zabbix agent

 <img src="http://i.imgur.com/0CAKDw5.png"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" />
     
Caso tudo de certo e a instancia passe a ser monitorada, sera realizado o fluxo normal quando todas as instancias na AWS já estão monitoradas.

Fluxo normal (Não há instancias a serem monitoradas)

 <img src="http://i.imgur.com/c2IZGJX.png"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" />
     
Caso a instancia não seja monitorada automaticamente e não há outras instancias que necessitem ser monitoradas, sera realizado o fluxo de limpeza do arquivo **instances_temp_no_monit** (este arquivo tem como objetivo não deixar que o script fique tentando monitorar a mesma instancia que ja foi realizado o processo de auto instalação do agent mas falhou, o script ignora as instancias que estão neste arquivo, isso para que possa realizar o processo de auto instalação em outras instancias que ainda não foram monitoradas )

Fluxo de limpeza do arquivo **instances_temp_no_monit**

 <img src="http://i.imgur.com/9CcADu5.png"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" />
     
Quando o processo de auto instalação já foi realizado na instancia e ela não foi monitorada automaticamente e ela não esta no arquivo **instances_temp_no_monit**, sera realizado o fluxo de alerta de instancia não monitorada automaticamente

Fluxo de alerta de instancia não monitorada automaticamente

 <img src="http://i.imgur.com/fjgTkbv.png"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" />
     
Caso não queira monitorar uma instancia, va em **Administration -> Scripts -> Nao monitorar** e coloque o IP privado da instancia que não deseja monitorar como parametro do comando, exemplo:

```
sudo python3 /usr/lib/zabbix/externalscripts/write-instances-no-necessary-monit.py "172.0.0.1"
```
Ir em algum problema do host: Zabbix Server e executar o script "Nao monitorar"

